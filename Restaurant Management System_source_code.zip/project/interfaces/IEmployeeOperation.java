package interfaces;
import java.lang.*;
import classes.*;
import classes.Employee;

public interface IEmployeeOperation{

	public void giveCusFeedback(String feed);
	public void giveEmpFeedback(String feed);
	void getEmployeeDetails();
}